package com.znsd.pay.main;

import org.apache.catalina.core.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.alipay.api.DefaultAlipayClient;
import com.znsd.pay.controller.PayController;

public class Main {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext app = new ClassPathXmlApplicationContext("applicationContext.xml");
		PayController bean = app.getBean("payController",PayController.class);
	}
}
