﻿package com.znsd.pay.config;

import java.io.FileWriter;
import java.io.IOException;

/* *
 *类名：AlipayConfig
 *功能：基础配置类
 *详细：设置帐户有关信息及返回路径
 *修改日期：2017-04-05
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 *该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 */

public class AlipayConfig {
	
//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓

	// 应用ID,您的APPID，收款账号既是您的APPID对应支付宝账号
	public static String app_id = "2016101700710967";
	
	// 商户私钥，您的PKCS8格式RSA2私钥
    public static String merchant_private_key = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAJ8kr1HEAPw6HSs78/C/wqXMIaMBoZjZoX4sP9ai+Jq4LuNjkRLmqk7Mk9bI2ms9SSUNwvIwmafG8F8Z+mhsyi98AkFxgg/k6QSJ7BipAxGCGhn9uw00p2IoSjrMXDcpz4HsGfxgR3gzgBGPT8ROtHaXTHW10EHeXK/62NOqxi1lAgMBAAECgYEAgA0nmJYq6MjmAYy7CyNxPrES+7NrUK8Et55pO45klTHQYJ0T9W5u6PrJllCFFzb37P22t+ONL6fub8daar3mrKcxhx5DtP2AQD27BSqEDUQf20QdP190X60KHVyHrXwUTXYetD6oj7LbmTKjt+tHthyPTkg4ylp8Qoz/qUWo5uECQQDuiJL/4JJRKMijTccWndO0RcTuYubg7065tbUd/BPQVB9ddytw1kg20AaHoiE0O9Lg1aeMRYCBdC0I0GAb2R1dAkEAqsvnLR93o4+y0ML1B67BoYyzOITZUvfCLYExo6bEq6rTqdrt4b5HCO3880tFA/oDjoNf8Jn9w1kV8B/FlLFHqQJAPgyY8KbiaOpLBu/8kg2MPKDJkZl4pZqayARUkPA51z+KyS1ux3N2ZYvHpxCtwoCtYn8xjnOl8gbekCRkW9omoQJAH7Ng4RsqFY2iXuUQnbBt+BIpYaAmxiN+QvvrvrhBYKuARdKAvJmYjau+e1nJIYfSCS2RLRMn6o4qaDs9bO/KoQJACPFQ8y2COs90nJ0Mw6rIjAxwHokmdx05l+XweeBeSGh7ThO81niicWJ9mKDxS+sThGDwA4nwcHVNheiIn7bPug==";

	// 支付宝公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应APPID下的支付宝公钥。
    public static String alipay_public_key = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDIgHnOn7LLILlKETd6BFRJ0GqgS2Y3mn1wMQmyh9zEyWlz5p1zrahRahbXAfCfSqshSNfqOmAQzSHRVjCqjsAw1jyqrXaPdKBmr90DIpIxmIyKXv4GGAkPyJ/6FTFY99uhpiq0qadD/uSzQsefWo0aTvP/65zi3eof7TcZ32oWpwIDAQAB";
    		
	// 服务器异步通知页面路径  需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	public static String notify_url = "http://localhost:8080/alipay.trade.page.pay-JAVA-UTF-8/notify_url.jsp";

	// 页面跳转同步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	public static String return_url = "http://localhost:8080/alipay.trade.page.pay-JAVA-UTF-8/return_url.jsp";

	// 签名方式
	public static String sign_type = "RSA";
	
	// 字符编码格式
	public static String charset = "utf-8";
	
	// 支付宝网关
	public static String gatewayUrl = "https://openapi.alipaydev.com/gateway.do";
	
	// 支付宝网关
	public static String log_path = "C:\\";


//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

    /** 
     * 写日志，方便测试（看网站需求，也可以改成把记录存入数据库）
     * @param sWord 要写入日志里的文本内容
     */
    public static void logResult(String sWord) {
        FileWriter writer = null;
        try {
            writer = new FileWriter(log_path + "alipay_log_" + System.currentTimeMillis()+".txt");
            writer.write(sWord);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

