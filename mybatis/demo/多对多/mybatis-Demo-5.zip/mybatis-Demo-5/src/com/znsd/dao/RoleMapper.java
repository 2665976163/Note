package com.znsd.dao;

import java.util.List;

import com.znsd.bean.Role;

public interface RoleMapper {
	List<Role> findAll();
}	
